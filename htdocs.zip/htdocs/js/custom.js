var data = [
    {
        "id": 1, "name": "lost", "treeNum": "2", "nameJ": "道に迷った", "nameA": "لقد ضاعت",
        "detail": [
            { "id": 1, "name": "tent", "nameJ": "テント", "nameA": "خيمة" },
            { "id": 2, "name": "bus", "nameJ": "バス", "nameA": "حافلة" },
            { "id": 3, "name": "train", "nameJ": "電車", "nameA": "قطار كهربائي" },
            { "id": 4, "name": "makkah", "nameJ": "メッカ", "nameA": "مكة المكرمة" },
            { "id": 5, "name": "arafat", "nameJ": "アラファト山", "nameA": "جبل عرفات" }
        ]
    },
    {
        "id": 2, "name": "pain", "treeNum": "2", "nameJ": "体調が悪い", "nameA": "مشكلة في الجسم",
        "detail": [
            { "id": 1, "name": "head", "nameJ": "頭", "nameA": "رئيس" },
            { "id": 2, "name": "stomach", "nameJ": "お腹", "nameA": "معدة" },
            { "id": 3, "name": "foot", "nameJ": "足", "nameA": "قدم" },
            { "id": 4, "name": "back", "nameJ": "背中", "nameA": "الى الخلف" },
            { "id": 5, "name": "throat", "nameJ": "のど", "nameA": "حلق" }
        ]
    },
    { "id": 3, "name": "water", "treeNum": "1", "nameJ": "喉が渇いた", "nameA": "أنا عطشان." },
    { "id": 4, "name": "food", "treeNum": "1", "nameJ": "お腹が空いた", "nameA": "أنا جائع" },
    { "id": 5, "name": "call", "treeNum": "1", "nameJ": "お土産", "nameA": "تخزين حيث تباع الهدايا التذكارية" },
    { "id": 6, "name": "lost_baggage", "treeNum": "1", "nameJ": "ものを無くした", "nameA": "الأمتعة المفقودة" },
    { "id": 7, "name": "get_separated", "treeNum": "1", "nameJ": "はぐれた", "nameA": "ضال" },
    { "id": 8, "name": "toilet", "treeNum": "1", "nameJ": "トイレ", "nameA": "مرحاض" },
    { "id": 9, "name": "police", "treeNum": "1", "nameJ": "警察", "nameA": "شرطة" }
];
$(document).ready(function () {


    $(".logo").on('click tap', function () {
        location.reload();
    });
    $(".btnDemo").on('click tap', function () {
        init1stWindow();
    });

});



function init1stWindow() {
    $("#startbox").addClass("placeDone");
    $("#iconbox1").removeClass("placeWait");

    var html = "";
    for (var i in data) {
        html += '<span data-id="selet_' + data[i]["id"] + '" data-name="' + data[i]["name"] + '" class="frame frame1"><img src="images/SVG/illust_' + data[i]["id"] + '.svg"><span class="nameTitle">' + data[i]["nameJ"] + '</span><span class="nameTitle">' + data[i]["nameA"] + '</span></span>';
    }
    $("#iconbox1").html(html);

    $(".frame1").on('click tap', function () {
        var arrFrame = $(this).attr("data-id").split("_");
        var pageNum = arrFrame.length - 1;
        var selectionNum = Number(arrFrame[1]);
        var w = $(window).width();
        var h = $(window).height();
        var addIconHtml = '<span data-id="add_1" id="frameSelect1" class="frameSecelt frameSelect1"><img src="images/SVG/illust_' + selectionNum + '.svg"></span>';
        $('body').append(addIconHtml);
        $('#frameSelect1').css({ 'top': $(this).offset().top + 'px', 'left': $(this).offset().left + 'px' });
        $('#frameSelect1').velocity({
            left: "3vw",
            top: h - 0.17 * w + "px",
            width: "15vw",
            height: "15vw"
        }, {
                duration: 600,
                easing: "easeOutCubic",
                queue: "",
                begin: undefined,
                progress: undefined,
                complete: undefined,
                display: undefined,
                visibility: undefined,
                loop: false,
                delay: 0,
                mobileHA: true
            });
        if (data[selectionNum - 1]["treeNum"] > 1) {
            init2ndWindow(selectionNum);
            $("#iconbox" + pageNum).addClass("placeDone");
            $("#iconbox" + (pageNum + 1)).removeClass("placeWait");
        } else {
            $("#iconbox" + pageNum).addClass("placeDone");
            $("#answerbox").removeClass("placeWait");
            showDetail(selectionNum);
        }
    });
    $("#menu").removeClass("menuClose");
    $("#footer").removeClass("footerClose");
}

function init2ndWindow(selectionNum) {

    var html = "";
    var dataSet = data[selectionNum - 1]["detail"];
    for (var i in dataSet) {
        html += '<span data-id="selet_' + selectionNum + '_' + dataSet[i]["id"] + '" data-name="' + dataSet[i]["name"] + '" class="frame frame2"><img src="images/SVG/illust_' + selectionNum + '_' + dataSet[i]["id"] + '.svg"><span class="nameTitle">' + dataSet[i]["nameJ"] + '</span><span class="nameTitle">' + dataSet[i]["nameA"] + '</span></span>';
    }
    $("#iconbox2").html(html);

    $(".frame2").on('click tap', function () {
        var arrFrame = $(this).attr("data-id").split("_");
        var pageNum = arrFrame.length - 1;
        var selectionNum = Number(arrFrame[1]);
        var w = $(window).width();
        var h = $(window).height();
        var selectionDetailNum = Number(arrFrame[2]);
        var addIconHtml = '<span data-id="add_2" id="frameSelect2" class="frameSecelt frameSelect2"><img src="images/SVG/illust_' + selectionNum + '_' + selectionDetailNum + '.svg"></span>';
        $('body').append(addIconHtml);
        $('#frameSelect2').css({ 'top': $(this).offset().top + 'px', 'left': $(this).offset().left + 'px' });
        $('#frameSelect2').velocity({
            left: "21vw",
            top: h - 0.17 * w + "px",
            width: "15vw",
            height: "15vw"
        }, {
                /* Velocity.jsのデフォルトのオプション */
                duration: 400,
                easing: "easeOutCubic",
                queue: "",
                begin: undefined,
                progress: undefined,
                complete: undefined,
                display: undefined,
                visibility: undefined,
                loop: false,
                delay: 0,
                mobileHA: true
            });
        showDetail(selectionNum + '_' + selectionDetailNum);
        $("#iconbox" + pageNum).addClass("placeDone");
        $("#answerbox").removeClass("placeWait");
    });


}

function showDetail(htmlId) {
    eval("var html= html_" + htmlId + ";");
    $("#answerbox").html(html + '<div class="answerbottom"></div>');

}

var html_1_1 = (function () { /*
        <div class="titleBox">
            <div>あなたのテントへの経路</div>
            <div>الطريق من هنا إلى خيمت</div>
        </div>
        <img class="mapImg" src="images/answerpage/01_01_tent.png">
        <div class="tellbox">
            <a class="btnTel" href="tel:_819088888888">
                <span>オペレーターに繋ぐ</span>
                <span>سوف تتصل المشغل؟</span>
            </a>
            <a class="btnTel" href="tel:_819088888888">
                <span>コーディネーターに電話</span>
                <span>اتصل بالمنسق</span>
            </a>
        </div>
    */}).toString().match(/(?:\/\*(?:[\s\S]*?)\*\/)/).pop().replace(/^\/\*/, "").replace(/\*\/$/, "");

var html_1_2 = (function () { /*
        <div class="titleBox">
            <div>近くのバス停と時刻表</div>
            <div>محطة الحافلات القريبة والجدول الزمني</div>
        </div>
        <img class="mapImg" src="images/answerpage/01_02_bus.png">

        <div>
            <ul class="list-group">
              <li class="list-group-item">
                メッカ｜مكة
                <span class="badge badge-pill">19:30</span>
                <span class="badge badge-pill">17:30</span>
                <span class="badge badge-pill">15:30</span>
                <span class="badge badge-pill">13:30</span>
                <span class="badge badge-pill">11:30</span>
                <span class="badge badge-pill">9:30</span>
              </li>

              <li class="list-group-item">
                メディナ｜المدينة
                <span class="badge badge-pill">16:00</span>
                <span class="badge badge-pill">14:00</span>
                <span class="badge badge-pill">12:00</span>
                <span class="badge badge-pill">10:00</span>
              </li>

            </ul>
        </div>

        <div class="tellbox">
            <a class="btnTel" href="tel:_819088888888">
                <span>バスのオペレーターに電話</span>
                <span>اتصل بمشغل الحافلات</span>
            </a>
            <a class="btnTel" href="tel:_819088888888">
                <span>コーディネーターに電話</span>
                <span>اتصل بالمنسق</span>
            </a>
        </div>
    */}).toString().match(/(?:\/\*(?:[\s\S]*?)\*\/)/).pop().replace(/^\/\*/, "").replace(/\*\/$/, "");

var html_1_3 = (function () { /*
        <div class="titleBox">
            <div>近くの駅と時刻表</div>
            <div>بالقرب من المحطة والجدول الزمني</div>
        </div>
        <img class="mapImg" src="images/answerpage/01_03_train.png">

        <div>
            <ul class="list-group">
              <li class="list-group-item">
                メッカ｜مكة
                <span class="badge badge-pill">19:30</span>
                <span class="badge badge-pill">17:30</span>
                <span class="badge badge-pill">15:30</span>
                <span class="badge badge-pill">13:30</span>
                <span class="badge badge-pill">11:30</span>
                <span class="badge badge-pill">9:30</span>
              </li>

              <li class="list-group-item">
                メディナ｜المدينة
                <span class="badge badge-pill">16:00</span>
                <span class="badge badge-pill">14:00</span>
                <span class="badge badge-pill">12:00</span>
                <span class="badge badge-pill">10:00</span>
              </li>

            </ul>
        </div>

        <div class="tellbox">
            <a class="btnTel" href="tel:_819088888888">
                <span>駅に電話</span>
                <span>اتصل بالمحطة</span>
            </a>
            <a class="btnTel" href="tel:_819088888888">
                <span>コーディネーターに電話</span>
                <span>اتصل بالمنسق</span>
            </a>
        </div>
    */}).toString().match(/(?:\/\*(?:[\s\S]*?)\*\/)/).pop().replace(/^\/\*/, "").replace(/\*\/$/, "");

var html_1_4 = (function () { /*
        <div class="titleBox">
            <div>メッカまでの経路</div>
            <div>اتجاه مكة</div>
        </div>
        <img class="mapImg" src="images/answerpage/01_04_makkah.png">

        <div class="tellbox">
            <a class="btnTel" href="tel:_819088888888">
                <span>オペレーターに繋ぐ</span>
                <span>سوف تتصل المشغل؟</span>
            </a>
            <a class="btnTel" href="tel:_819088888888">
                <span>コーディネーターに電話</span>
                <span>اتصل بالمنسق</span>
            </a>
        </div>
    */}).toString().match(/(?:\/\*(?:[\s\S]*?)\*\/)/).pop().replace(/^\/\*/, "").replace(/\*\/$/, "");

var html_1_5 = (function () { /*
        <div class="titleBox">
            <div>アラファト山までの経路</div>
            <div>اتجاه جبل عرفات</div>
        </div>
        <img class="mapImg" src="images/answerpage/01_05_arafat.png">

        <div class="tellbox">
            <a class="btnTel" href="tel:_819088888888">
                <span>オペレーターに繋ぐ</span>
                <span>سوف تتصل المشغل؟</span>
            </a>
            <a class="btnTel" href="tel:_819088888888">
                <span>コーディネーターに電話</span>
                <span>اتصل بالمنسق</span>
            </a>
        </div>
    */}).toString().match(/(?:\/\*(?:[\s\S]*?)\*\/)/).pop().replace(/^\/\*/, "").replace(/\*\/$/, "");

var html_2_1 = (function () { /*
        <div class="titleBox">
            <div>近くの病院</div>
            <div>مستشفى قريب</div>
        </div>
        <img class="mapImg" src="images/answerpage/07_hospital.png">

        <div class="tellbox">
            <a class="btnTel" href="tel:_819088888888">
                <span>病院に電話する</span>
                <span>اتصل بالمستشفى</span>
            </a>
            <a class="btnTel" href="tel:_819088888888">
                <span>コーディネーターに電話</span>
                <span>اتصل بالمنسق</span>
            </a>
        </div>
    */}).toString().match(/(?:\/\*(?:[\s\S]*?)\*\/)/).pop().replace(/^\/\*/, "").replace(/\*\/$/, "");

var html_2_2 = (function () { /*
        <div class="titleBox">
            <div>近くの病院</div>
            <div>مستشفى قريب</div>
        </div>
        <img class="mapImg" src="images/answerpage/07_hospital.png">

        <div class="tellbox">
            <a class="btnTel" href="tel:_819088888888">
                <span>病院に電話する</span>
                <span>اتصل بالمستشفى</span>
            </a>
            <a class="btnTel" href="tel:_819088888888">
                <span>コーディネーターに電話</span>
                <span>اتصل بالمنسق</span>
            </a>
        </div>
    */}).toString().match(/(?:\/\*(?:[\s\S]*?)\*\/)/).pop().replace(/^\/\*/, "").replace(/\*\/$/, "");

var html_2_3 = (function () { /*
        <div class="titleBox">
            <div>近くの病院</div>
            <div>مستشفى قريب</div>
        </div>
        <img class="mapImg" src="images/answerpage/07_hospital.png">

        <div class="tellbox">
            <a class="btnTel" href="tel:_819088888888">
                <span>病院に電話する</span>
                <span>اتصل بالمستشفى</span>
            </a>
            <a class="btnTel" href="tel:_819088888888">
                <span>コーディネーターに電話</span>
                <span>اتصل بالمنسق</span>
            </a>
        </div>
    */}).toString().match(/(?:\/\*(?:[\s\S]*?)\*\/)/).pop().replace(/^\/\*/, "").replace(/\*\/$/, "");

var html_2_4 = (function () { /*
        <div class="titleBox">
            <div>近くの病院</div>
            <div>مستشفى قريب</div>
        </div>
        <img class="mapImg" src="images/answerpage/07_hospital.png">

        <div class="tellbox">
            <a class="btnTel" href="tel:_819088888888">
                <span>病院に電話する</span>
                <span>اتصل بالمستشفى</span>
            </a>
            <a class="btnTel" href="tel:_819088888888">
                <span>コーディネーターに電話</span>
                <span>اتصل بالمنسق</span>
            </a>
        </div>
    */}).toString().match(/(?:\/\*(?:[\s\S]*?)\*\/)/).pop().replace(/^\/\*/, "").replace(/\*\/$/, "");

var html_2_5 = (function () { /*
        <div class="titleBox">
            <div>近くの病院</div>
            <div>مستشفى قريب</div>
        </div>
        <img class="mapImg" src="images/answerpage/07_hospital.png">

        <div class="tellbox">
            <a class="btnTel" href="tel:_819088888888">
                <span>病院に電話する</span>
                <span>اتصل بالمستشفى</span>
            </a>
            <a class="btnTel" href="tel:_819088888888">
                <span>コーディネーターに電話</span>
                <span>اتصل بالمنسق</span>
            </a>
        </div>
    */}).toString().match(/(?:\/\*(?:[\s\S]*?)\*\/)/).pop().replace(/^\/\*/, "").replace(/\*\/$/, "");

var html_3 = (function () { /*
        <div class="titleBox">
            <div>水が手に入る場所</div>
            <div>الأماكن التي يمكنك الحصول على الماء</div>
        </div>
        <img class="mapImg" src="images/answerpage/03_water.png">

        <div class="tellbox">
            <a class="btnTel" href="tel:_819088888888">
                <span>オペレーターに繋ぐ</span>
                <span>سوف تتصل المشغل؟</span>
            </a>
            <a class="btnTel" href="tel:_819088888888">
                <span>コーディネーターに電話</span>
                <span>اتصل بالمنسق</span>
            </a>
        </div>
    */}).toString().match(/(?:\/\*(?:[\s\S]*?)\*\/)/).pop().replace(/^\/\*/, "").replace(/\*\/$/, "");

var html_4 = (function () { /*
        <div class="titleBox">
            <div>近くの食堂</div>
            <div>مطعم قريب</div>
        </div>
        <img class="mapImg" src="images/answerpage/04_food.png">

        <div>
            <ul class="list-group">
                <li class="list-group-item">
                レストラン1｜1مطعم
                <span class="badge badge-pill">★★</span>
                </li>

                <li class="list-group-item">
                レストラン2｜2مطعم
                <span class="badge badge-pill">★★★★</span>
                </li>

                <li class="list-group-item">
                レストラン3｜3مطعم
                <span class="badge badge-pill">★★★★★</span>
                </li>

                <li class="list-group-item">
                レストラン4｜4مطعم
                <span class="badge badge-pill">★</span>
                </li>

                <li class="list-group-item">
                メッカ｜مكة
                <span class="badge badge-pill">★★</span>
                </li>
            </ul>
        </div>


        <div class="tellbox">
            <a class="btnTel" href="tel:_819088888888">
                <span>オペレーターに繋ぐ</span>
                <span>سوف تتصل المشغل؟</span>
            </a>
            <a class="btnTel" href="tel:_819088888888">
                <span>コーディネーターに電話</span>
                <span>اتصل بالمنسق</span>
            </a>
        </div>
    */}).toString().match(/(?:\/\*(?:[\s\S]*?)\*\/)/).pop().replace(/^\/\*/, "").replace(/\*\/$/, "");

var html_5 = (function () { /*
        <div class="titleBox">
            <div>お土産が買える場所</div>
            <div>تخزين حيث تباع الهدايا التذكارية</div>
        </div>
        <img class="mapImg" src="images/answerpage/05_souvenir.png">

        <div>
            <ul class="list-group">
                <li class="list-group-item">
                ショップ1｜1متجر تذكارات
                <span class="badge badge-pill">★★</span>
                </li>

                <li class="list-group-item">
                ショップ2｜2متجر تذكارات
                <span class="badge badge-pill">★★★★</span>
                </li>

                <li class="list-group-item">
                ショップ3｜3متجر تذكارات
                <span class="badge badge-pill">★★★★★</span>
                </li>

                <li class="list-group-item">
                ショップ4｜4متجر تذكارات
                <span class="badge badge-pill">★</span>
                </li>
            </ul>
        </div>


        <div class="tellbox">
            <a class="btnTel" href="tel:_819088888888">
                <span>オペレーターに繋ぐ</span>
                <span>سوف تتصل المشغل؟</span>
            </a>
            <a class="btnTel" href="tel:_819088888888">
                <span>コーディネーターに電話</span>
                <span>اتصل بالمنسق</span>
            </a>
        </div>
    */}).toString().match(/(?:\/\*(?:[\s\S]*?)\*\/)/).pop().replace(/^\/\*/, "").replace(/\*\/$/, "");

var html_6 = (function () { /*
        <div class="titleBox">
            <div>落とし物の預かり所</div>
            <div>مكتب للحفاظ على العناصر المفقودة</div>
        </div>
        <img class="mapImg" src="images/answerpage/06_lost_baggage.png">

        <div class="tellbox">
            <a class="btnTel" href="tel:_819088888888">
                <span>オペレーターに繋ぐ</span>
                <span>سوف تتصل المشغل؟</span>
            </a>
            <a class="btnTel" href="tel:_819088888888">
                <span>コーディネーターに電話</span>
                <span>اتصل بالمنسق</span>
            </a>
        </div>
    */}).toString().match(/(?:\/\*(?:[\s\S]*?)\*\/)/).pop().replace(/^\/\*/, "").replace(/\*\/$/, "");

var html_7 = (function () { /*
        <div class="titleBox">
            <div>コーディネーターとはぐれた</div>
            <div>لقد علقت مع المنسق</div>
        </div>
        <img class="mapImg" src="images/answerpage/08_get_separated.png">

        <div class="tellbox">
            <a class="btnTel" href="tel:_819088888888">
                <span>コーディネーターに電話</span>
                <span>اتصل بالمنسق</span>
            </a>
        </div>
    */}).toString().match(/(?:\/\*(?:[\s\S]*?)\*\/)/).pop().replace(/^\/\*/, "").replace(/\*\/$/, "");

var html_8 = (function () { /*
        <div class="titleBox">
            <div>近くのトイレ</div>
            <div>مكان المرحاض</div>
        </div>
        <img class="mapImg" src="images/answerpage/09_toilet.png">

        <div class="tellbox">
            <a class="btnTel" href="tel:_819088888888">
                <span>オペレーターに繋ぐ</span>
                <span>سوف تتصل المشغل؟</span>
            </a>
            <a class="btnTel" href="tel:_819088888888">
                <span>コーディネーターに電話</span>
                <span>اتصل بالمنسق</span>
            </a>
        </div>
    */}).toString().match(/(?:\/\*(?:[\s\S]*?)\*\/)/).pop().replace(/^\/\*/, "").replace(/\*\/$/, "");

var html_9 = (function () { /*
        <div class="titleBox">
            <div>警察の場所</div>
            <div>مركز الشرطة</div>
        </div>
        <img class="mapImg" src="images/answerpage/10_police.png">

        <div class="tellbox">
            <a class="btnTel" href="tel:_819088888888">
                <span>警察署に電話する</span>
                <span>اتصل بمركز الشرطة</span>
            </a>
            <a class="btnTel" href="tel:_819088888888">
                <span>コーディネーターに電話</span>
                <span>اتصل بالمنسق</span>
            </a>
        </div>
    */}).toString().match(/(?:\/\*(?:[\s\S]*?)\*\/)/).pop().replace(/^\/\*/, "").replace(/\*\/$/, "");


var ss = "";

function openQRCamera(node) {
    var reader = new FileReader();
    reader.onload = function () {
        node.value = "";
        qrcode.callback = function (res) {
            if (res instanceof Error) {
                alert("No QR code found. Please make sure the QR code is within the camera's frame and try again.");
            } else {
                node.parentNode.previousElementSibling.value = res;
                init1stWindow();
                $("#startnox").addClass("placeDone");
                $("#iconbox1").removeClass("placeWait");
            }
        };
        qrcode.decode(reader.result);
    };
    reader.readAsDataURL(node.files[0]);
}